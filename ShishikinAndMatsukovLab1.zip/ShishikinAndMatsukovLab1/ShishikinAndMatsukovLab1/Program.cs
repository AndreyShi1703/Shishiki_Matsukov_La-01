﻿using System;

namespace ShishikinAndMatsukovLab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            //Напишите программу, чтобы найти значение указанного выражения
            int num11 = (101 + 0) / 3;
            Console.WriteLine(num11);
            double num12 = 3 * Math.Exp(-6) * 10000000.1;
            Console.WriteLine(num12);
            bool num13 = true && true;
            Console.WriteLine(num13);
            bool num14 = false && true;
            Console.WriteLine(num14);
            bool num15 = (false && false) && (false && true);
            Console.WriteLine(num15);
            bool num16 = (false && false) && (true && true);
            Console.WriteLine(num16);

            //Напишите программу, которая принимает четыре целых числа от пользователя и выводит надпись равно, если все четыре равны, и не равно в противном случае
            int num21;
            int num22;
            int num23;
            int num24;

            Console.WriteLine("Напишите 4 числа");

            num21 = Convert.ToInt32(Console.ReadLine());
            num22 = Convert.ToInt32(Console.ReadLine());
            num23 = Convert.ToInt32(Console.ReadLine());
            num24 = Convert.ToInt32(Console.ReadLine());
            if (num21 == num22 && num21 == num23 && num21 == num24)
            {
                Console.WriteLine("=");
            }
            else
            {
                Console.WriteLine("!=");
            }

            //Напишите программу для поиска num32 самых больших элементов в заданном массиве. Элементы в массиве могут располагаться в любом порядке
            Console.WriteLine("Программа выводит к наибольших элементов массива");
            int[] num31 = new int[random.Next(1, 100 + 1)];

            for (int i = 0; i < num31.Length; i++)
            {
                num31[i] = random.Next(1, 100 + 1);
            }

            BubbleSort(num31);

            Console.WriteLine("Введите к");

            int num32 = Convert.ToInt32(Console.ReadLine());
            int num33 = num31.Length - num32;

            for (int i = num31.Length - 1; i > num33 - 1; i--)
            {
                Console.Write(num31[i] + " ");
            }

            //Напишите программу для поиска k наименьших элементов в заданном массиве. Элементы в массиве могут располагаться в любом порядке.
            Console.WriteLine("\nПрограмма выводит к наименьших элементов массива");
            for (int i = 0; i < num32; i++)
            {
                Console.Write(num31[i] + " ");
            }

            //Напишите программу для поиска чисел, превышающих среднее значение чисел данного массива.
            Console.WriteLine("Массив создан, вот числа которые больше среднего значения");

            int[] num51 = new int[random.Next(1, 100 + 1)];
            int num52 = 0;
            double num53;

            for (int i = 0; i < num51.Length; i++)
            {
                num51[i] = random.Next(1, 100 + 1);
                num52 += num51[i];
            }

            foreach (int i in num51)
            {
                Console.Write(i + " ");
            }

            num53 = num52 / num51.Length;

            Console.WriteLine("\n" + num53 + "\n");


            foreach (int i in num51)
            {
                if (i > num53)
                {
                    Console.Write(i + " ");
                }
            }

            //Напишите программу для умножения двух заданных целых чисел без использования оператора умножения(*).
            Console.WriteLine("Введите целое первое число");
            int num61 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите целое второе число");
            int num62 = Convert.ToInt32(Console.ReadLine());
            int num63 = 0;

            for (int i = 0; i < num62; i++)
            {
                num63 += num61;
            }

            Console.WriteLine("Их произведение =" + num63);

            //Напишите для разбиения заданного массива целых чисел на четное число первым и нечетное число вторым.
            Console.WriteLine("Массив создан и разбит на четные и не четные числа");

            int[] num72 = new int[num31.Length];
            int[] num73 = new int[num31.Length];
            for (int i = 0; i < num31.Length; i++)
            {
                double num71 = num31[i] % 2;
                if (num71 != 0)
                {
                    num72[i] = num31[i];
                }
                else
                {
                    num73[i] = num31[i];
                }
            }
            Console.WriteLine("Не чётные ==");
            foreach (int i in num72)
            {
                if (i != 0)
                {
                    Console.Write(i + ", ");
                }
            }
            Console.WriteLine();
            Console.WriteLine("Чётные ==");
            foreach (int i in num73)
            {
                if (i != 0)
                {
                    Console.Write(i + ", ");
                }
            }


            //Напишите програмиу для преобразования температуры из градуса Фаренгейта в градус Цельсия.
            Console.WriteLine("Напишите температуру в Фаренгейтах");
            double num81 = Convert.ToDouble(Console.ReadLine());
            double num82 = (num81 - 32) * 5 / 9;
            Console.WriteLine("Температура в цельсиях = {0}", num82);

            //Напишите программу для вычисления индекса массы тела (ИМТ). ИМТ = ВЕС / РОСТ2
            Console.WriteLine("Напишите вес тела");
            double num91 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Напишите рост в  метрах");
            double num92 = Convert.ToDouble(Console.ReadLine());
            double num93 = num91 / num92;
            Console.WriteLine("Ваш индекс массы тела = " + num93);

            //Напишите, которая считывает число и отображает квадрат, куб и четвертую степень.
            Console.WriteLine("Напишите число, для отображения его квадрата, куба и его 4 степени");

            int num101 = Convert.ToInt32(Console.ReadLine());

            double num102 = Math.Pow(num101, 2);
            Console.WriteLine(num102);
            double num103 = Math.Pow(num101, 3);
            Console.WriteLine(num103);
            double num104 = Math.Pow(num101, 4);
            Console.WriteLine(num104);

            //Напишите программу, чтобы проверить, могут ли три заданные длины сторон (целые числа) образовать треугольник или нет.
            Console.WriteLine("Укажите 3 стороны");

            int num111 = Convert.ToInt32(Console.ReadLine());
            int num112 = Convert.ToInt32(Console.ReadLine());
            int num113 = Convert.ToInt32(Console.ReadLine());

            if (num111 + num112 > num113 || num111 + num113 > num112 || num113 + num112 > num111)
            {
                Console.WriteLine("Эти стороны могут образовать треугольник");
            }
            else
            {
                Console.WriteLine("Эти стороны не могут образовать треугольник");
            }
        }

        static void BubbleSort(int[] Array)
        {
            for (int i = 0; i < Array.Length; i++)
            {
                for (int j = 0; j < Array.Length - 1; j++)
                {
                    if (Array[j] > Array[j + 1])
                    {
                        int temp = Array[j];
                        Array[j] = Array[j + 1];
                        Array[j + 1] = temp;
                    }
                }
            }
        }
    }
}
